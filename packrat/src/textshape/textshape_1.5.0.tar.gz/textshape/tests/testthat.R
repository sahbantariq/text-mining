library("testthat")
library("textshape")

test_check("textshape")